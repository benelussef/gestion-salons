<?php
session_start();
$base="inscrits";
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,$base);
if(isset($_POST['Register'])){
if(!empty($_POST['Nom']) && !empty($_POST['Prenom']) && !empty($_POST['Email']) && !empty($_POST['Tel'])){
  $Nom=$_SESSION['Nom']=$_POST['Nom'];
  $Prenom=$_SESSION['Prenom']=$_POST['Prenom'];
  $Email=$_SESSION['Email']=$_POST['Email'];
  $Tel=$_SESSION['Tel']=$_POST['Tel'];
  $request="INSERT INTO preinscrits (Nom,Prenom,Email,Telephone) VALUES ('$Nom','$Prenom','$Email','$Tel')";
  $query=mysqli_query($connection,$request);
  $alert='
  <div class="container">
  <div class="alert alert-success " role="alert">
  booking successfully!
  </div>
  </div>
  ';
}
else{
  $Remplir="veuillez remplir tous les champs";
  
}}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link href='../css/formulaire1.css' rel='stylesheet' type='text/css'>
    <title>Register</title>
</head>
<body>
<div><?php if(isset($alert)){ echo $alert;}?></div>
    <div class="form-style-8">
        <h2>Book Now</h2>
        <form method="POST" action="Register.php">
          <input type="text" name="Nom" placeholder="Nom" />
          <input type="text" name="Prenom" placeholder="Prenom" />
          <input type="email" name="Email" placeholder="Email" />
          <input type="text" name="Tel" placeholder="Téléphone" />
          <input type="submit" name="Register" value="Register" />
          <h6 align="center" style="color: red;"><?php if(isset($Remplir)){ echo $Remplir;}?></h6>
        </form>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-eMNCOe7tC1doHpGoWe/6oMVemdAVTMs2xqW4mwXrXsW0L84Iytr2wi5v2QjrP/xp" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js" integrity="sha384-cn7l7gDp0eyniUwwAZgrzD06kc/tftFf19TOAs2zVinnD/C7E91j9yyk5//jjpt/" crossorigin="anonymous"></script>
</body>
</html>