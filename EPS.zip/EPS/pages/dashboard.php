<?php
if(isset($_POST['Logout'])){
    header("Location: ../pages/login.php");
}
include_once 'conx.php';
$result = mysqli_query($conn,"SELECT * FROM std_data");
//traitement de l'envois d'email
 ini_set('display_errors',1);
 error_reporting(E_ALL);
 $header="MIME-Version :1.0\r\n";
 $header.='From:"YOUSSEF"<youssefbenelfakir99@gmail.com>'."\n";
 $header.='Content-Type:text/html; charset="utf-8"'."\n";
 $header.='Content-Transfer-Encoding: 8bit';
 $msg="Hello world!!";
 $requet="SELECT * FROM preinscrits";
 $Query = mysqli_query($conn,$requet);
 $res=mysqli_fetch_All($Query);
 if(isset($_POST['envoyer'])){
     for($i=0;$i<count($res);$i++){
       if(mail($res[$i][3],"Demande",$msg,$header)){
         $ok="the reminder is well done";
       }
       else{
        echo "Msg echouee!!";
       }}}
//traitement des statistique
$request ="SELECT Niveau FROM std_data";
$query=mysqli_query($conn,$request);
$resultat=mysqli_fetch_All($query);
$Tronc = 0;
$Pr=0;
$Dm=0;
$BacU=0;
$BacD=0;
$BacT=0;
$BacQ=0;
$BacC=0;
for($i=0;$i<count($resultat);$i++){
    if($resultat[$i][0]=="Tronc comm"){
            $Tronc++;
    }
    elseif($resultat[$i][0]=="1ère année"){
           $Pr++;
    }
    elseif ($resultat[$i][0]=="2ème année") {
           $Dm++;
    }
    elseif ($resultat[$i][0]=="Bac+1") {
          $BacU++;
    }
    elseif ($resultat[$i][0]=="Bac+2") {
           $BacD++;
    }
    elseif ($resultat[$i][0]=="Bac+3") {
           $BacT++;
    }
    elseif ($resultat[$i][0]=="Bac+4") {
           $BacQ++;
 }  
 elseif ($resultat[$i][0]=="Bac+5") {
            $BacC++;
}
}

?>

<!DOCTYPE html>
<html lang="fr">
    <head>
    <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.5.0/chart.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.25/b-1.7.1/b-html5-1.7.1/b-print-1.7.1/datatables.min.js"></script>
        <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>

         <script type=text/javascript src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type=text/javascript src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.25/b-1.7.1/b-html5-1.7.1/b-print-1.7.1/datatables.min.js"></script>
        <title>Eps-admin</title>

        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../css/metisMenu.min.css" rel="stylesheet">

        <!-- DataTables CSS -->
        <link href="../css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DataTables Responsive CSS -->
        <link href="../css/dataTables/dataTables.responsive.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="dashboard.php"><img class="logo" src="../logo/logo1.png" width="100px" height="70px"></a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>


                <ul class="nav navbar-right navbar-top-links">

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> Profil <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a name="Logout" href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">

                            <li>
                                <a href="#"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>

                            <li>
                                <a href="tables.php"><i class="fa fa-table fa-fw"></i> Registered</a>
                            </li>


                         
                            <li>
                                <form method="POST" action="#">
                                    <div class="reminder">
                            <i class="fa fa-paper-plane-o fa-fw"></i><input type="button" data-toggle="modal" data-target="#myModal" name="Reminder" value="Reminder" class="lien" >
                                    </div>
                                </form>
                            </li>
                            <li>
                                <a href="Preinscrits.php"><i class="fa fa-user-circle-o fa-fw"></i> Pre-registered</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>
            <!-- Debut Modal-->
        <div class="row">
            <div class="col-md-6">
                <div class="modal fade" id="myModal">
                    <div class="modal-dialog modal-lg">
                    <div class="modal-content bg-light">
                         <div class="modal-header">
                             <h1>Confirmation</h1>
                         </div>
                         <div class="modal-body">
                         confirmation of the reminder by email ?
                         </div>
                         <div class="modal-footer">
                           <form method="POST" action="#">
                             <button class="btn btn-danger">Close</button>
                             <button class="btn btn-success" name="envoyer">confirm</button>
                           </form>
                          </div>
                         </div>
                    </div>
                </div>   
             </div>
        </div>
            <!-- Fin Modal-->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Statistics</h1>
                              <?php if(!empty($ok)){echo "<div class="."'alert alert-success'"." role="."'alert'>"."$ok"."</div>";}?> 
                            </div>                         
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                Student Statistics By Level
                                </div>
                                <!-- /.panel-heading -->
                                
                            </div>
                            <!-- /.panel -->
                            <canvas id="Mychart">

                           </canvas>
                        </div>
                        <div class="col-lg-6">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                Number of registered students</div>
                                <!-- /.panel-heading -->
                                </div>
                            <!-- /.panel -->
                        <!--chart-->
                        <!--debut du user statistic-->
                        <div class="container bootstrap snippet ">
    <div class="row">
    <div class="col-lg-3 col-sm-4">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading dark-blue"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content dark-blue">
          <div class="circle-tile-description text-faded">Registration</div>
          <div class="circle-tile-number text-faded "><?php echo count($resultat);?></div>
        </div>
      </div>
    </div>
     
    <div class="col-lg-3 col-sm-4">
      <div class="circle-tile ">
        <a href="#"><div class="circle-tile-heading red"><i class="fa fa-users fa-fw fa-3x"></i></div></a>
        <div class="circle-tile-content red">
          <div class="circle-tile-description text-faded"> Pre-registration</div>
          <div class="circle-tile-number text-faded "><?php echo count($res);?></div>
        </div>
      </div>
    </div> 
  </div> 
</div>
                             <!--fin du user statistic-->
                            </div>
                            
                    </div>

                    <!-- /.row -->

                    <!-- /.row -->

                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->
    

        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>


        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- DataTables JavaScript -->
        <script src="../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../js/dataTables/dataTables.bootstrap.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>
        <script>
     var lien=document.getElementsByClassName("lien");
       lien[0].addEventListener('click',function(){
        $("#myModal").modal('show':true);
       });
        </script>
         <script>

        function ExportToExcel(type, fn, dl) {
            var elt = document.getElementById('dataTables-example');
            var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
            return dl ?
                XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
                XLSX.writeFile(wb, fn || ('datatableEXCEL.' + (type || 'xlsx')));
        }

    </script>
        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>
        <script>
    function printData()
{
   var divToPrint=document.getElementById("dataTables-example");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}
</script>
        <script type="text/javascript">

function copytable(el) {
    var urlField = document.getElementById(el)
    var range = document.createRange()
    range.selectNode(urlField)
    window.getSelection().addRange(range)
    document.execCommand('copy')
}

</script>

    </body>
</html>
<style>
    .logo{
        margin-top: -25%;
    }
    input{
        border: none;
        background: transparent;

    }
    .reminder{
    text-align: inherit;
    width: 100%;
    border: none;
    color: #337ab7;
    background: transparent;
    }
    .reminder:focus, .reminder:hover {
    text-decoration: none;
    background-color: #eee;}
    .reminder {
    position: relative;
    display: block;
    padding: 10px 15px;}
    .sidebar ul li a.active {
    background-color: none;
}
</style>
<script>
       var myChart=document.getElementById('Mychart').getContext('2d');

        var Chart= new Chart(myChart,{
        type:'radar',
        data:{
            labels:['Tronc comm','1ère année','2ème année','Bac+1','Bac+2','Bac+3','Bac+4','Bac+5'],
            datasets:[{
                label:'Students',
                data:[
                    <?php echo "$Tronc";?>,
                    <?php echo "$Pr";?>,
                    <?php echo "$Dm";?>,
                    <?php echo "$BacU";?>,
                    <?php echo "$BacD";?>,
                    <?php echo "$BacT";?>,
                    <?php echo "$BacQ";?>,
                    <?php echo "$BacC";?>
                ],
                backgroundColor:[
                      'red',
                      'green',
                      'yellow',
                      'blue',
                      'orange',
                      'gray',
                      'purple',
                      'black'
                ]
            }]
        },
        options:{
        
        }
        });
</script>
<style>
    body{
        overflow-x: hidden;  }
   .circle-tile {
    margin-bottom: 15px;
    text-align: center;
}
.circle-tile-heading {
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-radius: 100%;
    color: #FFFFFF;
    height: 80px;
    margin: 0 auto -40px;
    position: relative;
    transition: all 0.3s ease-in-out 0s;
    width: 80px;
}
.circle-tile-heading .fa {
    line-height: 80px;
}
.circle-tile-content {
    padding-top: 50px;
}
.circle-tile-number {
    font-size: 26px;
    font-weight: 700;
    line-height: 1;
    padding: 5px 0 15px;
}
.circle-tile-description {
    text-transform: uppercase;
}
.circle-tile-footer {
    background-color: rgba(0, 0, 0, 0.1);
    color: rgba(255, 255, 255, 0.5);
    display: block;
    padding: 5px;
    transition: all 0.3s ease-in-out 0s;
}
.circle-tile-footer:hover {
    background-color: rgba(0, 0, 0, 0.2);
    color: rgba(255, 255, 255, 0.5);
    text-decoration: none;
}
.circle-tile-heading.dark-blue:hover {
    background-color: #2E4154;
}
.circle-tile-heading.green:hover {
    background-color: #138F77;
}
.circle-tile-heading.orange:hover {
    background-color: #DA8C10;
}
.circle-tile-heading.blue:hover {
    background-color: #2473A6;
}
.circle-tile-heading.red:hover {
    background-color: #CF4435;
}
.circle-tile-heading.purple:hover {
    background-color: #7F3D9B;
}
.tile-img {
    text-shadow: 2px 2px 3px rgba(0, 0, 0, 0.9);
}

.dark-blue {
    background-color: #34495E;
}
.green {
    background-color: #16A085;
}
.blue {
    background-color: #2980B9;
}
.orange {
    background-color: #F39C12;
}
.red {
    background-color: #E74C3C;
}
.purple {
    background-color: #8E44AD;
}
.dark-gray {
    background-color: #7F8C8D;
}
.gray {
    background-color: #95A5A6;
}
.light-gray {
    background-color: #BDC3C7;
}
.yellow {
    background-color: #F1C40F;
}
.text-dark-blue {
    color: #34495E;
}
.text-green {
    color: #16A085;
}
.text-blue {
    color: #2980B9;
}
.text-orange {
    color: #F39C12;
}
.text-red {
    color: #E74C3C;
}
.text-purple {
    color: #8E44AD;
}
.text-faded {
    color: rgba(255, 255, 255, 0.7);
}
.container{
    text-align:center;
}
</style>
