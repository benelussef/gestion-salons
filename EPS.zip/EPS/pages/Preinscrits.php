<?php
if(isset($_POST['Logout'])){
    header("Location: ../pages/login.php");
}
include_once 'conx.php';
$result = mysqli_query($conn,"SELECT * FROM preinscrits");
//traitement de l'envois d'email
 ini_set('display_errors',1);
 error_reporting(E_ALL);
 $emails=array("benelfakir.yussef@gmail.com","bdeyoungleaders@gmail.com","ensaagadirade@gmail.com");
 $header="MIME-Version :1.0\r\n";
 $header.='From:"YOUSSEF"<youssefbenelfakir99@gmail.com>'."\n";
 $header.='Content-Type:text/html; charset="utf-8"'."\n";
 $header.='Content-Transfer-Encoding: 8bit';
 $msg="Hello world!!";
 $requet="SELECT * FROM preinscrits";
 $Query = mysqli_query($conn,$requet);
 $res=mysqli_fetch_All($Query);
 if(isset($_POST['envoyer'])){
     for($i=0;$i<count($res);$i++){
       if(mail($res[$i][3],"Demande",$msg,$header)){
         $ok="OK";
       }
       else{
        echo "Msg echouee!!";
       }}}
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
    <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.25/b-1.7.1/b-html5-1.7.1/b-print-1.7.1/datatables.min.js"></script>
        <script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>

         <script type=text/javascript src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type=text/javascript src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.25/b-1.7.1/b-html5-1.7.1/b-print-1.7.1/datatables.min.js"></script>
        <title>Eps-admin</title>

        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../css/metisMenu.min.css" rel="stylesheet">

        <!-- DataTables CSS -->
        <link href="../css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

        <!-- DataTables Responsive CSS -->
        <link href="../css/dataTables/dataTables.responsive.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="dashboard.php"><img class="logo" src="../logo/logo1.png" width="100px" height="70px"></a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>


                <ul class="nav navbar-right navbar-top-links">

                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> Profil <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a name="Logout" href="login.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">

                            <li>
                                <a href="dashboard.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>

                            <li>
                                <a href="tables.php"><i class="fa fa-table fa-fw"></i> Registered</a>
                            </li>


                            <li>
                                <a href="#"><i class="fa fa-download" ></i> Data Download <span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="javascript:ExportToExcel('xlsx')"> EXCEL </a>
                                    </li>
                                    <li>
                                        <a href="javascript:printData()"> PDF</a>
                                    </li> <li>
                                        <a href="javascript:copytable('dataTables-example')">Copy Data </a>
                                    </li>

                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li>
                                <form method="POST" action="Preinscrits.php">
                                    <div class="reminder">
                            <i class="fa fa-paper-plane-o fa-fw"></i><input type="button" data-toggle="modal" data-target="#myModal" name="Reminder" value="Reminder" class="lien" >
                                    </div>
                                </form>
                            </li>
                            <li>
                                <a href="Preinscrits.php"><i class="fa fa-user-circle-o fa-fw"></i> Pre-registered</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>
            <!-- Debut Modal-->
        <div class="row">
            <div class="col-md-6">
                <div class="modal fade" id="myModal">
                    <div class="modal-dialog modal-lg">
                    <div class="modal-content bg-light">
                         <div class="modal-header">
                             <h1>Confirmation</h1>
                         </div>
                         <div class="modal-body">
                         confirmation of the reminder by email ?
                         </div>
                         <div class="modal-footer">
                           <form method="POST" action="#">
                             <button class="btn btn-danger">Close</button>
                             <button class="btn btn-success" name="envoyer">confirm</button>
                           </form>
                          </div>
                         </div>
                    </div>
                </div>   
             </div>
        </div>
            <!-- Fin Modal-->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Table</h1>
                            <?php if(!empty($ok)){echo "<div class="."'alert alert-success'"." role="."'alert'>"."$ok"."</div>";}?> 
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    DataTables Advanced Tables
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">

                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>id</th>
                                                    <th>Nom</th>
                                                    <th>Prenom(s)</th>
                                                    <th>Email</th>
                                                    <th>Tele</th>
                                                </tr>
                                            </thead>
<?php
//$i=5;
$row = mysqli_fetch_All($result);
   // var_dump($row);
    function data($row){
      for($i=0;$i<count($row);$i++) {
        $id=$row[$i][0];
        $nom=$row[$i][1];
        $Prenom=$row[$i][2];
        $Email=$row[$i][3];
        $Tele=$row[$i][4];
        echo "
        <tr>
                                                    <th>$id</th>
                                                    <th>$nom</th>
                                                    <th>$Prenom</th>
                                                    <th>$Email</th>
                                                    <th>$Tele</th>
                                                   
            </tr>";
          }

    }
   //
?>
                                            <tbody>


<?php
          data($row);




?>

                                                </tbody>
                                            </table>
                                                       </div>
                                    <!-- /.table-responsive -->

                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>

                    <!-- /.row -->

                    <!-- /.row -->

                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->


        <!-- jQuery -->
        <script src="../js/jquery.min.js"></script>


        <!-- Bootstrap Core JavaScript -->
        <script src="../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../js/metisMenu.min.js"></script>

        <!-- DataTables JavaScript -->
        <script src="../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../js/dataTables/dataTables.bootstrap.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../js/startmin.js"></script>
        <script>
     var lien=document.getElementsByClassName("lien");
       lien[0].addEventListener('click',function(){
        $("#myModal").modal('show':true);
       });
      </script>

         <script>

        function ExportToExcel(type, fn, dl) {
            var elt = document.getElementById('dataTables-example');
            var wb = XLSX.utils.table_to_book(elt, { sheet: "sheet1" });
            return dl ?
                XLSX.write(wb, { bookType: type, bookSST: true, type: 'base64' }) :
                XLSX.writeFile(wb, fn || ('datatableEXCEL.' + (type || 'xlsx')));
        }

    </script>
        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>
        <script>
    function printData()
{
   var divToPrint=document.getElementById("dataTables-example");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}
</script>
        <script type="text/javascript">

function copytable(el) {
    var urlField = document.getElementById(el)
    var range = document.createRange()
    range.selectNode(urlField)
    window.getSelection().addRange(range)
    document.execCommand('copy')
}

</script>
    </body>
</html>
<style>
    .logo{
        margin-top: -25%;
    }
    input{
        border: none;
        background: transparent;

    }
    .reminder{
    text-align: inherit;
    width: 100%;
    border: none;
    color: #337ab7;
    background: transparent;
    }
    .reminder:focus, .reminder:hover {
    text-decoration: none;
    background-color: #eee;}
    .reminder {
    position: relative;
    display: block;
    padding: 10px 15px;}
    .sidebar ul li a.active {
    background-color: none;
}
</style>